package com.mycompany.gestiondepersonajesp;


interface CSVSerializable {
    void Serializacion();
}
