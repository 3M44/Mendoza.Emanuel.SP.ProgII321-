package com.mycompany.gestiondepersonajesp;

import java.util.List;





public class GestionDePersonajeSP {

    public static void main(String[] args) {
        String pathFiles = "src/main/java/resources/";
        String pathTexto = pathFiles + "archivo.csv";
        
        Inventario<Personaje> inventario = new Inventario<>();
        hardcodearPersonajes(inventario);
        inventario.listar();
        
        System.out.println("--------------------------------------------");
        System.out.println("Ordenados:");//123213
        inventario.Ordenar();
        
        
        System.out.println("-----------------------------------------");
        System.out.println("Filtrados segun criterio");
        List<Personaje> listaPersonaje = inventario.filtrar(p -> p.getClase().equals(ClasePersonaje.ARQUERO));
        
        listaPersonaje.forEach(System.out::println);
        
        System.out.println("--------------------------");
        System.out.println("Nivel aumenta 5");
         List<Personaje> comestiblesAumentados = inventario.transformar(
                p -> {p.aumentarNivel(5);
                    return p;
        });
         
        comestiblesAumentados.forEach(System.out::println);
        
        System.out.println("-------------------------------------");
        inventario.guardarEmpleadosCSV(pathTexto);
        inventario.cargarDesdeArchivo(pathTexto);
        inventario.listar();
                
    }
    
    public static void hardcodearPersonajes(Inventario<Personaje> inventario){
        inventario.agregar(new Personaje(21, "Jose", ClasePersonaje.MAGO, 10));
        inventario.agregar(new Personaje(1, "Maria", ClasePersonaje.ARQUERO, 20));
        inventario.agregar(new Personaje(16, "Carlos", ClasePersonaje.GUERRERO, 5));
        inventario.agregar(new Personaje(100, "Juan", ClasePersonaje.ARQUERO, 66));
        inventario.agregar(new Personaje(61, "Leandro", ClasePersonaje.MAGO, 84));
        inventario.agregar(new Personaje(93, "Pepe", ClasePersonaje.GUERRERO, 100));
        
    }
}
