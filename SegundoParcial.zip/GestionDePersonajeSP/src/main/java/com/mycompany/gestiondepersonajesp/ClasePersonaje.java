package com.mycompany.gestiondepersonajesp;


public enum ClasePersonaje {
    GUERRERO,
    MAGO,
    ARQUERO;
}
