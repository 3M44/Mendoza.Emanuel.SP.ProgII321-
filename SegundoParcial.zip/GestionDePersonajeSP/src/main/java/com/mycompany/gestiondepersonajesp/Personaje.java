package com.mycompany.gestiondepersonajesp;

import java.io.Serializable;


public class Personaje implements Comparable<Personaje>, CSVSerializable, Serializable{

    private int id;
    private String nombre;
    private ClasePersonaje clase;
    private int nivel;

    public Personaje(int id, String nombre, ClasePersonaje clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public int getId() {
        return id;
    }

    public ClasePersonaje getClase() {
        return clase;
    }

    public int getNivel() {
        return nivel;
    }
    
    public void aumentarNivel(int nivelAumento) {
        nivel = nivel + nivelAumento;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre:" + nombre + ", Clase:" + clase + ", Nivel;" + nivel;
    }

    @Override
    public int compareTo(Personaje p) {
        return this.nombre.compareTo(p.nombre);
    }

    @Override
    public void Serializacion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public static Personaje fromCSV(String empleadoCSV){
        Personaje aux = null;
        String[] values = empleadoCSV.split(",");
                if (values.length == 4){
                    int id = Integer.parseInt(values[0]);
                    String nombre = values[1];
                    int nivel = Integer.parseInt(values[2]);
                    ClasePersonaje clase = ClasePersonaje.valueOf(values[3]);
                    
                    aux = new Personaje(id, nombre, clase, nivel);
                    
                }
        return aux;
    }
    
    public String toCSV() {
        return id + "," + nombre + "," + clase + "," + nivel;
    }
    

    

    
}
