package com.mycompany.gestiondepersonajesp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T>  implements Serializable{
    List <T> items = new LinkedList<>();
    
    public void agregar(T item) {
        if (item == null){
            throw new IllegalArgumentException("No puedo almacenar un nulo");
        }
        items.add(item);
    }
    
    public void eliminar(int indice) {
        if (indice >= items.size() || indice < 0){
            throw new ArrayIndexOutOfBoundsException("Te falto/paso el indice");
        }
        items.remove(indice);
    }
    
    public Iterator<T> iterator(){
        if (!items.isEmpty() && items.get(0) instanceof Comparable){
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return items.iterator();
    }
    
    public Iterator<T> iterator(Comparator<? super T> comparador){
        List<T> aux = new ArrayList<>(items);
        aux.sort(comparador);
        return aux.iterator();
      
    }
    
    public void listar(){
        listar((Comparator<? super T>) Comparator.naturalOrder());
    }
    
    public void listar(Comparator<? super T> comparador){
        System.out.println("Contenido del Inventario: ");
        Iterator<T> it = iterator(comparador);
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
    
    public void Ordenar(){
        listar((Comparator<? super T>) Comparator.naturalOrder());
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for(T item : items){
            if (criterio.test(item)){
                aux.add(item);
            }
        }
        return aux;
    }
    
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> aux = new ArrayList<>();
        for(T item: items){
            aux.add(transformacion.apply(item));
        }
        return aux;
    }
    
    public void serializarPersonaje(List<? extends Personaje> lista, String path){
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(lista);
            
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public void guardarEmpleadosCSV(String path){
        File archivo = new File(path);
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){
            
            for(T e: items){
                bw.write(e + "\n");
        }
        } catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        
    }
    
    public void cargarDesdeArchivo(String path) {
        File archivo = new File(path);
        items.clear();
        try(BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null){
                items.add((T)linea);
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
